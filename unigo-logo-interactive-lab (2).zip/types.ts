
export interface AnalysisResponse {
  comparison: string;
  designChoices: string[];
  vibeSummary: string;
}

export interface LogoProps {
  size?: number;
}
