
import React from 'react';
import { AnalysisResponse } from '../types';

interface AnalysisDisplayProps {
  analysis: AnalysisResponse | null;
  loading: boolean;
}

export const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ analysis, loading }) => {
  if (loading) {
    return (
      <div className="flex flex-col gap-4 p-6 bg-zinc-900/50 rounded-xl border border-zinc-800 animate-pulse">
        <div className="h-4 bg-zinc-800 rounded w-3/4"></div>
        <div className="h-4 bg-zinc-800 rounded w-1/2"></div>
        <div className="h-20 bg-zinc-800 rounded"></div>
      </div>
    );
  }

  if (!analysis) return null;

  return (
    <div className="p-8 bg-zinc-900/80 backdrop-blur-md rounded-2xl border border-purple-500/30 shadow-2xl space-y-6">
      <h2 className="text-2xl font-bold text-purple-400 border-b border-purple-900 pb-2">Design Intelligence</h2>
      
      <div>
        <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-widest mb-2">Heritage Analysis</h3>
        <p className="text-zinc-200 leading-relaxed italic">"{analysis.comparison}"</p>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-widest mb-2">Technical Execution</h3>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {analysis.designChoices.map((choice, i) => (
            <li key={i} className="flex items-center gap-2 text-zinc-300">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
              {choice}
            </li>
          ))}
        </ul>
      </div>

      <div className="pt-4 border-t border-zinc-800">
        <p className="text-sm text-zinc-500 font-medium">Brand Vibe Summary:</p>
        <p className="text-purple-300 font-semibold">{analysis.vibeSummary}</p>
      </div>
    </div>
  );
};
