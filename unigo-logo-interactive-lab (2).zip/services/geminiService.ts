
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export async function analyzeLogoConcept() {
  const prompt = `
    Analyze the logo design for 'UniGo'. 
    Reference the 'Souled Store' logo: its cheeky, minimalist face, and simple bold geometric shapes.
    The 'UniGo' logo is a vertical black rectangular suitcase with a purple graffiti glow.
    On hover, it grows a handle, its 'U' turns into a smile, and eyes pop up with a wink.
    Provide a professional design analysis in JSON format including comparison, design choices, and vibe summary.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            comparison: { type: Type.STRING },
            designChoices: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            vibeSummary: { type: Type.STRING }
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return null;
  }
}
