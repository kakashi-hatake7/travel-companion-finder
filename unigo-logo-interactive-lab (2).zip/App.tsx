
import React, { useState, useEffect } from 'react';
import { UniGoLogo } from './components/UniGoLogo';
import { AnalysisDisplay } from './components/AnalysisDisplay';
import { analyzeLogoConcept } from './services/geminiService';
import { AnalysisResponse } from './types';

const App: React.FC = () => {
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchAnalysis = async () => {
      setLoading(true);
      const data = await analyzeLogoConcept();
      setAnalysis(data);
      setLoading(false);
    };
    fetchAnalysis();
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 md:p-12 gap-12 bg-[#050505] relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-purple-600 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] bg-purple-900 rounded-full blur-[100px]" />
      </div>

      <header className="text-center z-10 max-w-2xl">
        <h1 className="text-5xl md:text-7xl font-extrabold mb-4 bg-gradient-to-r from-white to-purple-400 bg-clip-text text-transparent italic">
          UniGo.
        </h1>
        <p className="text-zinc-400 text-lg md:text-xl font-medium">
          The luggage of a new generation. Dynamic, expressive, and cheeky.
        </p>
      </header>

      <main className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-12 items-center z-10">
        <div className="flex flex-col items-center justify-center space-y-8">
          <div className="p-8 bg-zinc-900/30 rounded-full border border-zinc-800/50 hover:border-purple-500/50 transition-colors duration-500 group relative">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
              Hover to Activate
            </div>
            <UniGoLogo />
          </div>
          <p className="text-zinc-500 text-sm font-medium animate-pulse">
            Interactive Prototype v1.0
          </p>
        </div>

        <div className="space-y-6">
          <AnalysisDisplay analysis={analysis} loading={loading} />
          
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: 'Palette', val: '#A855F7' },
              { label: 'Style', val: 'Graffiti' },
              { label: 'Inspo', val: 'Souled Store' },
            ].map((stat, i) => (
              <div key={i} className="bg-zinc-900/40 p-4 rounded-xl border border-zinc-800 text-center">
                <div className="text-[10px] uppercase text-zinc-500 tracking-tighter mb-1">{stat.label}</div>
                <div className="text-purple-400 font-bold text-sm">{stat.val}</div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="mt-auto py-8 text-zinc-600 text-sm z-10">
        &copy; {new Date().getFullYear()} UniGo Creative Labs. All rights reserved.
      </footer>
    </div>
  );
};

export default App;
